# Limpeza do armazemento
rm(list = ls()) # Limpa o Ambiente
dev.off(dev.list()["RStudioGD"]) # Limpa os Plots
cat("\014") # Limpa o Console 


# CAPITULOS
#### 1 - Importação pacotes, funções e dataframe
#### 2 - Informações sobre o dataframe
#### 3 - Correlação e Teste de Hipótese
#### 4 - Verificação das Correlações


#### 1 - Importação pacotes e dataframe
### Instalação dos Pacotes
install.packages(c("readxl", "dplyr", "tidyverse", "ggplot2", "ggpubr", "corrplot", "PerformanceAnalytics", "broom"))

### Importação de Pacotes
library(readxl) # Usada para importar datasets em formato Excel (.xlsx)
library(dplyr) # Usada para manipulação e transformação eficiente de dados
library(tidyverse) # Coleção abrangente de pacotes para manipulação, visualização e análise de dados
library(ggplot2) # Utilizada para criação de gráficos estatísticos personalizáveis
library(ggpubr) # Estende o ggplot2 com funções adicionais para gráficos prontos e publicação



### Importação de Funções
## Função para calcular Métricas da variável
calcular_metricas_variavel <- function(dataframe, nome_coluna) {
  nome_coluna_sym <- rlang::enquo(nome_coluna)
  
  dataframe %>%
    summarise(
      n = n(),
      min = min(!!nome_coluna_sym, na.rm = TRUE),
      max = max(!!nome_coluna_sym, na.rm = TRUE),
      media = mean(!!nome_coluna_sym, na.rm = TRUE),
      mediana = median(!!nome_coluna_sym, na.rm = TRUE),
      sd = sd(!!nome_coluna_sym, na.rm = TRUE),
      error = qt(0.975, df = n - 1) * (sd / sqrt(n)),
      lower_bound = media - error,
      upper_bound = media + error
    )
}
#  Calcula número de observações, mínimo, máximo, média, mediana, desvio padrão, erro padrão, e limites superior e inferior de um intervalo de confiança da variável


## Função para identificar outliers
recuperar_outliers_df_iqr <- function(dataframe_original) {
  # Criar uma cópia do dataframe para trabalhar e evitar modificar o original diretamente
  df_trabalho <- dataframe_original
  indices_removidos <- c()
  
  # 1. Identificar e registrar observações com NA
  if (any(is.na(df_trabalho))) {
    na_indices <- which(rowSums(is.na(df_trabalho)) > 0)
    indices_removidos <- unique(c(indices_removidos, na_indices))
  }
  
  # 2. Identificar variáveis numéricas
  colunas_numericas <- sapply(df_trabalho, is.numeric)
  
  # 3. Iterar sobre as variáveis numéricas para identificar outliers
  for (col_name in names(df_trabalho[colunas_numericas])) {
    vetor <- df_trabalho[[col_name]]
    
    # Calcular Q1, Q3 e o IQR, ignorando NAs
    Q1 <- quantile(vetor, 0.25, na.rm = TRUE)
    Q3 <- quantile(vetor, 0.75, na.rm = TRUE)
    IQR_val <- Q3 - Q1
    
    # Definir os limites para outliers
    limite_inferior <- Q1 - 1.5 * IQR_val
    limite_superior <- Q3 + 1.5 * IQR_val
    
    # Identificar os índices das linhas com outliers nesta variável
    outlier_indices_coluna <- which(vetor < limite_inferior | vetor > limite_superior)
    
    # Adicionar esses índices à lista de observações a serem removidas
    indices_removidos <- unique(c(indices_removidos, outlier_indices_coluna))
  }
  
  # 4. Recuperar as observações completas com base nos índices identificados
  if (length(indices_removidos) > 0) {
    observacoes_com_outliers <- dataframe_original[sort(indices_removidos), , drop = FALSE]
    return(observacoes_com_outliers)
  } else {
    message("Nenhuma observação com NA ou outlier foi identificada para remoção.")
    return(NULL) # Retorna NULL se não houver outliers/NAs
  }
}
#  Identifica e retorna observações com valores ausentes (NA) ou outliers baseados no método do Intervalo Interquartil (IQR)


### Importação do dataframe
df <- read_excel("C:/Users/NAME/Downloads/databases/data.xlsx", sheet = "df")
# Contruida com base na base tratada, que tem 1556 observações
df2 <- read_excel("C:/Users/NAME/Downloads/databases/data.xlsx", sheet = "df2")
# Para análise especifica das situações de excesso de uso da internet



#### 2 - Informações sobre o dataframe
### Informações básicas do dataframe
glimpse(df)
# O dataframe contém 30 observações (linhas) e 5 variáveis (colunas)
# Os dados referem-se a crianças e adolescentes que utilizam a Internet uma ou mais de uma vez por dia


# Variáveis categóricas
df %>%
  distinct(renda)
# Cinco categorias de renda familiar: Até 1 SM (salário mínimo), Mais de 1 SM até 2 SM, Mais de 2 SM até 3 SM, Mais de 3 SM, e Não tem renda 

df %>%
  distinct(faixa_etaria)
# Três faixas etárias: de 11 a 12 anos, 13 a 14 anos, e 15 a 17 anos.

df %>%
  distinct(genero)
# Dois gêneros presentes: Masculino e Feminino.


summary(df)
# Variáveis categóricas: renda, faixa_etaria, genero.
# Variáveis numéricas: uso_resp, dispositivo, midia_social, e sit_excesso

# Estatísticas de uso_resp:
# Mínimo: 0.3333, Mediana: 0.8988, Média: 0.8842, Máximo: 1.0000  

# Estatísticas de dispositivo:
# Mínimo: 0.7308, Mediana: 0.9225, Média: 0.8992, Máximo: 1.0000    

# Estatísticas de midia_social:
# Mínimo: 0.5000, Mediana: 0.9534, Média: 0.9086, Máximo: 1.0000    

# Estatísticas de sit_excesso:
# Mínimo: 0.4000, Mediana: 0.5963, Média: 0.6132, Máximo: 1.0000    


summary(df2)
# Variáveis categóricas: renda, faixa_etaria, genero.
# Variáveis numéricas: T12_A, T12_B, T12_C, T12_D, e T12_E

# Estatísticas de T12_A:
# Mínimo: 0.0000, Mediana: 0.1525, Média: 0.1552, Máximo: 0.5000

# Estatísticas de T12_B:
# Mínimo: 0.0000, Mediana: 0.1850, Média: 0.2107, Máximo: 1.0000

# Estatísticas de T12_C:
# Mínimo: 0.0000, Mediana: 0.2563, Média: 0.2435, Máximo: 0.5000

# Estatísticas de T12_D:
# Mínimo: 0.0000, Mediana: 0.2100, Média: 0.2162, Máximo: 0.5000

# Estatísticas de T12_E:
# Mínimo: 0.0000, Mediana: 0.2488, Média: 0.2570, Máximo: 0.5000


### Percentual de responsáveis de adolescente que utilizam internet todos ou quase todos os dias
## Shapiro Test
shapiro.test(df$uso_resp)
# p-value = 1.786e-06
# A variável não segue uma distribuição normal

## Boxplot
ggplot(df, aes(x = "", y = uso_resp)) +
  geom_boxplot() +
  labs(title = "Boxplot Percentual de Responsáveis que Usam Internet todos ou quase todos os dias",
       x = NULL,
       y = "Percentual de Responsáveis") +
  theme_minimal()


### Percentual de adolescentes que possuem um dispositivo pessoal (computador, tablet, celular ou notebook) e utiliza a internet nele
## Shapiro Test
shapiro.test(df$dispositivo)
# p-value = 0.04086
# A variável não segue uma distribuição normal

## Boxplot
ggplot(df, aes(x = "", y = dispositivo)) +
  geom_boxplot() +
  labs(title = "Boxplot Percentual de Adolescentes que Usam Internet em Dispositivo Pessoal",
       x = NULL,
       y = "Percentual de Adolescentes") +
  theme_minimal()


### Percentual de adolescentes que têm um ou mais perfis próprios em mídias sociais
## Shapiro Test
shapiro.test(df$midia_social)
# p-value = 2.406e-05
# A variável não segue uma distribuição normal

## Boxplot
ggplot(df, aes(x = "", y = midia_social)) +
  geom_boxplot() +
  labs(title = "Boxplot Percentual de Adolescentes com Perfis em Mídias Sociais",
       x = NULL,
       y = "Percentual de Adolescentes") +
  theme_minimal()


### Percentual de adolescentes que viveram uma ou mais situações de uso excessivo da internet
## Shapiro Test
shapiro.test(df$sit_excesso)
# p-value = 0.008339
# A variável não segue uma distribuição normal

## Boxplot
ggplot(df, aes(x = "", y = sit_excesso)) +
  geom_boxplot() +
  labs(title = "Boxplot Percentual de Adolescentes em Situação de Uso Excessivo de Internet",
       x = NULL,
       y = "Percentual de Adolescentes") +
  theme_minimal()


### Identificação e remoção dos outliers das variaveis númericas
outliers <- recuperar_outliers_df_iqr(df)
# De 11 a 12 anos/Feminino/Não tem renda
# De 13 a 14 anos/Feminino/Não tem renda
# De 13 a 14 anos/Masculino/Não tem renda

outliers2 <- recuperar_outliers_df_iqr(df2)
# De 11 a 12 anos/Feminino/Não tem renda
# De 11 a 12 anos/Masculino/Não tem renda
# De 13 a 14 anos/Feminino/Mais de 3 SM
# De 13 a 14 anos/Feminino/Não tem renda
# De 13 a 14 anos/Masculino/Não tem renda
# De 15 a 17 anos/Feminino/Não tem renda

# Remoção de outliers de DF e DF2 
df_original <- df
df <- anti_join(df, outliers)

df2_original <- df2
df2 <- anti_join(df2, outliers2)


### Percentual de responsáveis de adolescente que utilizam internet todos ou quase todos os dias
## Métricas da variável
calcular_metricas_variavel(df, uso_resp)
#n            27
#minimo       0.796  
#maximo       1  
#media        0.896      
#mediana      0.895  
#sd           0.0699        
#error        0.0277       
#lower_bound  0.868              
#upper_bound  0.924


### Percentual de adolescentes que possuem um dispositivo pessoal (computador, tablet, celular ou notebook) e utiliza a internet nele
## Métricas da variável
calcular_metricas_variavel(df, dispositivo)
#n            27
#minimo       0.731  
#maximo       1  
#media        0.888      
#mediana      0.911  
#sd           0.0780        
#error        0.0309       
#lower_bound  0.857              
#upper_bound  0.919


### Percentual de adolescentes que têm um ou mais perfis próprios em mídias sociais
## Métricas da variável
calcular_metricas_variavel(df, midia_social)
#n            27
#minimo       0.731  
#maximo       1  
#media        0.917      
#mediana      0.953  
#sd           0.0923        
#error        0.0365       
#lower_bound  0.880              
#upper_bound  0.953


### Percentual de adolescentes que viveram uma ou mais situações de uso excessivo de internet
## Métricas da variável
calcular_metricas_variavel(df, sit_excesso)
#n            27
#minimo       0.4  
#maximo       0.8  
#media        0.589      
#mediana      0.593  
#sd           0.104        
#error        0.0411       
#lower_bound  0.548              
#upper_bound  0.630


### T12_A
## Métricas da variável
calcular_metricas_variavel(df2, T12_A)
#n            24
#minimo       0.0571  
#maximo       0.226  
#media        0.146      
#mediana      0.153  
#sd           0.0441        
#error        0.0186       
#lower_bound  0.128              
#upper_bound  0.165


### T12_B
## Métricas da variável
calcular_metricas_variavel(df2, T12_B)
#n            24
#minimo       0.132  
#maximo       0.276  
#media        0.190      
#mediana      0.185  
#sd           0.0381        
#error        0.0161       
#lower_bound  0.174              
#upper_bound  0.206


### T12_C
## Métricas da variável
calcular_metricas_variavel(df2, T12_C)
#n            24
#minimo       0.0822  
#maximo       0.5  
#media        0.254      
#mediana      0.256  
#sd           0.0952        
#error        0.0402       
#lower_bound  0.214              
#upper_bound  0.294


### T12_D
## Métricas da variável
calcular_metricas_variavel(df2, T12_D)
#n            24
#minimo       0  
#maximo       0.382  
#media        0.209      
#mediana      0.204  
#sd           0.0850        
#error        0.0359       
#lower_bound  0.173              
#upper_bound  0.244


### T12_E
## Métricas da variável
calcular_metricas_variavel(df2, T12_E)
#n            24
#minimo       0  
#maximo       0.48  
#media        0.255      
#mediana      0.240  
#sd           0.107        
#error        0.0454       
#lower_bound  0.209              
#upper_bound  0.300



#### 3 - Correlação e Testes de Hipótese
### Variaveis
## sit_excesso - Percentual de adolescentes que vivenciaram uma ou mais situações de excesso de uso da internet
## uso_resp - Percentual de responsáveis de adolescente que utilizam internet todos ou quase todos os dias
## dispositivo - Percentual de adolescentes que possuem um dispositivo pessoal (computador, tablet, celular ou notebook) e utiliza a internet nele
## midia_social - Percentual de adolescentes que têm um ou mais perfis próprios em mídias sociais
## T12_A - Percentual de adolescentes que vivenciaram uma situação de negligência de necessidades básicas (comer e/ou dormir) por causa do excesso de uso da internet
## T12_B - Percentual de adolescentes que vivenciaram uma situação de desconforto pela falta de acesso por causa do excesso de uso da internet
## T12_C - Percentual de adolescentes que vivenciaram uma situação de navegação sem propósito na internet por causa do excesso de uso da internet
## T12_D - Percentual de adolescentes que vivenciaram uma situação de priorização do uso da internet sobre outras atividades por causa do excesso de uso da internet
## T12_E - Percentual de adolescentes que vivenciaram uma situação de tentativa falha de reduzir o tempo online por causa do excesso de uso da internet


### Correlação de Spearman
## DF
cor_spearman_df <- cor.test(
  df$uso_resp, ##Adaptar nome da variável
  df$dispositivo, ##Adaptar nome da variável
  method = "spearman"
)
print(cor_spearman_df)

# DF2
cor_spearman_df2 <- cor.test(
  df2$T12_D, ##Adaptar nome da variável
  df2$T12_E, ##Adaptar nome da variável
  method = "spearman"
)
print(cor_spearman_df2)


## Resultados que não são estatisticamente significativos:
# sit_excesso e uso_resp
# p-value = 0.1349, rho = 0.2952541  

# sit_excesso e dispositivo
# p-value = 0.4331, rho = 0.157348  

# sit_excesso e midia_social
# p-value = 0.3173, rho = 0.1999546 

# uso_resp e midia_social
# p-value = 0.1716, rho = 0.2709917 

# T12_A e T12_B
# p-value = 0.5433, rho = -0.1304915 

# T12_A e T12_C
# p-value = 0.2611, rho = 0.2387995  

# T12_B e T12_C
# p-value = 0.5749, rho = 0.1204872  

# T12_A e T12_D
# p-value = 0.2878, rho = 0.2262345  

# T12_B e T12_D
# p-value = 0.2921, rho = 0.2242767  

# T12_A e T12_E
# p-value = 0.8338, rho = 0.04522722 

# T12_B e T12_E
# p-value = 0.9021, rho = 0.02652751


## Resultados que são estatisticamente significativos:
# uso_resp e dispositivo
# p-value = 0.0235, rho = 0.4345707  

# dispositivo e midia_social
# p-value = 1.375e-10, rho = 0.901661  

# T12_C e T12_D
# p-value = 0.000439, rho = 0.6608658

# T12_C e T12_E
# p-value = 0.00119, rho = 0.6214395

# T12_D e T12_E
# p-value = 0.0009937, rho = 0.6289692

# Todas correlações positivas


### Gráfico de correlação
## Das correlação de Spearman que foram estatisticamente significativas:
# LEGENDA: faixa etária (vermelho=11-12 anos, verde=13-14 anos e azul=15-17 anos) e gênero (círculo = feminino e quadrado = masculino)

# uso_resp e dispositivo
ggplot(df, aes(x = uso_resp, y = dispositivo)) +
  geom_point(aes(color = faixa_etaria, shape = genero, size = 2)) +
  geom_smooth(method = "lm", col = "red") +
  labs(
    title = "Relação entre Uso da Internet por Responsáveis e Posse de Dispositivo Pessoal",
    x = "Percentual de Responsáveis que Usam Internet todos ou quase todos os dias",
    y = "Percentual de Adolescentes que Usam Internet em um ou mais Dispositivos Pessoais"
  ) +
  scale_shape_manual(values = c("Feminino" = 19, "Masculino" = 15),
                     name = "Gênero") +
  theme_minimal() +
  theme(legend.position = "none")
# Correlação positiva moderada
# A faixa etária tem maior influência que o gênero, indicando que adolescentes mais velhos usam mais a internet em dispositivos pessoais devido à maior autonomia e menor controle parental

## Test
t_test_1 <- t.test(df$uso_resp, df$dispositivo)
print(t_test_1)
# t = 0.39717, df = 51.392, p-value = 0.6929
# Resultado não é estatisticamente significativo


# dispositivo e midia_social
ggplot(df, aes(x = dispositivo, y = midia_social)) +
  geom_point(aes(color = faixa_etaria, shape = genero, size = 2)) +
  geom_smooth(method = "lm", col = "red") +
  labs(
    title = "Relação entre Posse de Dispositivo Pessoal e Perfis em Mídias Sociais",
    x = "Percentual de Adolescentes que Usam Internet em um ou mais Dispositivos Pessoais",
    y = "Percentual de Adolescentes com um ou mais Perfis em Mídias Sociais"
  ) +
  scale_shape_manual(values = c("Feminino" = 19, "Masculino" = 15),
                     name = "Gênero") +
  theme_minimal() +
  theme(legend.position = "none")
# Correlação positiva forte
# O aumento da idade está associado a maior presença em mídias sociais, com progressão clara entre as faixas etárias

## Test
t_test_2 <- t.test(df$dispositivo, df$midia_social)
print(t_test_2)
# t = -1.245, df = 50.602, p-value = 0.2189
# Resultado não é estatisticamente significativo


# T12_C e T12_D
ggplot(df2, aes(x = T12_C, y = T12_D)) +
  geom_point(aes(color = faixa_etaria, shape = genero, size = 2)) +
  geom_smooth(method = "lm", col = "red") +
  labs(
    title = "Relação entre Navegação Sem Propósito na Internet e Priorização do Uso da Internet",
    x = "Percentual de Adolescentes que Navegaram Sem Propósito",
    y = "Percentual de Adolescentes que Priorizaram o Uso da Internet"
  ) +
  scale_shape_manual(values = c("Feminino" = 19, "Masculino" = 15),
                     name = "Gênero") +
  theme_minimal() +
  theme(legend.position = "none")
# Correlação positiva moderada
# Faixa etária e gênero não influenciam em um padrão de distribuição, apenas compõem subgrupos heterogêneos dentro do padrão de uso adverso

## Test
t_test_3 <- t.test(df2$T12_C, df2$T12_D)
print(t_test_3)
# t = 1.7559, df = 45.417, p-value = 0.08585
# Resultado não é estatisticamente significativo


# T12_C e T12_E
ggplot(df2, aes(x = T12_C, y = T12_E)) +
  geom_point(aes(color = faixa_etaria, shape = genero, size = 2)) +
  geom_smooth(method = "lm", col = "red") +
  labs(
    title = "Relação entre Navegação Sem Propósito e Tentativa Falha de Reduzir Tempo Online",
    x = "Percentual de Adolescentes que Navegaram Sem Propósito",
    y = "Percentual de Adolescentes que Falharam ao tentar Reduzir Tempo Online"
  ) +
  scale_shape_manual(values = c("Feminino" = 19, "Masculino" = 15),
                     name = "Gênero") +
  theme_minimal() +
  theme(legend.position = "none")
# Correlação positiva moderada
# Há grande dispersão por faixa etária, mas o gênero feminino tende a concentrar-se na parte superior do gráfico, indicando leve predominância

## Test
t_test_4 <- t.test(df2$T12_C, df2$T12_E)
print(t_test_4)
# t = -0.017945, df = 45.347, p-value = 0.9858
# Resultado não é estatisticamente significativo


# T12_D e T12_E
ggplot(df2, aes(x = T12_D, y = T12_E)) +
  geom_point(aes(color = faixa_etaria, shape = genero, size = 2)) +
  geom_smooth(method = "lm", col = "red") +
  labs(
    title = "Relação entre Priorização do Uso da Internet e Tentativa Falha de Reduzir Tempo Online",
    x = "Percentual de Adolescentes que Priorizaram o Uso da Internet",
    y = "Percentual de Adolescentes que Falharam ao tentar Reduzir Tempo Online"
  ) +
  scale_shape_manual(values = c("Feminino" = 19, "Masculino" = 15),
                     name = "Gênero") +
  theme_minimal() +
  theme(legend.position = "none")
# Correlação positiva moderada
# Faixa etária e gênero não influenciam em um padrão de distribuição, apenas compõem subgrupos heterogêneos dentro do padrão de uso adverso

## Test
t_test_5 <- t.test(df2$T12_D, df2$T12_E)
print(t_test_5)
# t = -1.6549, df = 43.685, p-value = 0.1051
# Resultado não é estatisticamente significativo




#### 4 - Verificação das Correlações
library(corrplot) # Usada para criar visualizações gráficas (plot) de matrizes de correlação
library(PerformanceAnalytics) # Utilizada para criar gráficos de correlação com histogramas e testes estatísticos
library(broom) # Converte objetos estatísticos (como modelos) em data frames organizados


### Matriz
## Chart Correlação
# DF
df_num <- df %>%
  select(uso_resp, dispositivo, midia_social, sit_excesso)

chart.Correlation(df_num, histogram = TRUE, pch = 19)

# DF2
df2_num <- df2 %>%
  select(T12_A, T12_B, T12_C, T12_D, T12_E)

chart.Correlation(df2_num, histogram = TRUE, pch = 19)


## Corrplot
# DF
df_num_M <- cor(df_num)

corrplot(df_num_M, type = "upper", order = "hclust",
         tl.col = "black", tl.srt = 45)

# DF2
df2_num_M <- cor(df2_num)

corrplot(df2_num_M, type = "upper", order = "hclust",
         tl.col = "black", tl.srt = 45)